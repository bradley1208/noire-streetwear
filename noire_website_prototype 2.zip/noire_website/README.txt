NOIRÉ website prototype
=======================

FILES
- index.html: responsive single-page website prototype

HOW TO PREVIEW
1. Open index.html in a current web browser.
2. Test the navigation, concept collection, early-access form and WhatsApp button.

IMPORTANT BEFORE PUBLISHING
- WhatsApp: edit index.html and set WHATSAPP_NUMBER near the bottom of the file.
  Use international format with digits only, including country code; for Zimbabwe,
  use 263 followed by the mobile number without its leading 0.
- Early-access form: currently shows a demo message and does not save email addresses.
  Connect a form provider or backend before publishing.
- Products: mockups are concept illustrations, not real products or stock.
- Domain/hosting: this is a prototype, not a published live website.

LOW-COST NEXT STEP
Publish the static page on a free static hosting service, then test the live page on
your phone. Check the host's current terms and availability before choosing it.
